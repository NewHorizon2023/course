package Exam.Question2;

/**
 * @author Xiangnan Liu
 * @date 2023-07-27 15:54
 */
public class Test {
    public static void main(String[] args) {
        System.out.println(Conversion.binaryToDecimal("10"));
        System.out.println(Conversion.binaryToDecimal("100101"));
        System.out.println(Conversion.binaryToDecimal("1101011001"));
        // System.out.println(Conversion.binaryToDecimal("2"));
    }
}
